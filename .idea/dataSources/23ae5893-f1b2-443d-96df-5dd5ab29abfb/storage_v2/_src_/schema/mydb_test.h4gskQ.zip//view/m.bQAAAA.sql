create view m as
  select
    `s`.`id`     AS `id`,
    `s`.`name`   AS `name`,
    `c`.`c_name` AS `c_name`,
    `c`.`grade`  AS `grade`
  from (`mydb_test`.`score` `c` left join `mydb_test`.`student` `s` on ((`s`.`id` = `c`.`stu_id`)));

